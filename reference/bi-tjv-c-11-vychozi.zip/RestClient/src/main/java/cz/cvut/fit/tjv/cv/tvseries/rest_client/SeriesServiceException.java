package cz.cvut.fit.tjv.cv.tvseries.rest_client;

public class SeriesServiceException extends RuntimeException {
    public SeriesServiceException(Throwable cause) {
        super(cause);
    }
}
